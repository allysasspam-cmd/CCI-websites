const articles = [
{ id:"education-access", title:"Why Educational Access Matters Beyond the Classroom", category:"Education", date:"August 19, 2026", author:"CCI", imageClass:"", excerpt:"Education is more than textbooks and classrooms. It can shape confidence, opportunity and how young people imagine their futures.", content:"<p>Education can influence far more than academic achievement. Access to books, technology, supportive teachers and safe spaces to learn can shape how children understand their own possibilities.</p><p>At CCI, we believe educational access should include the resources and relationships that help young people turn curiosity into confidence.</p><h2>Opportunity changes what children imagine</h2><p>When a child has access to new information, mentorship and meaningful encouragement, the range of futures they can imagine can expand.</p>" },
{ id:"community-action", title:"What Does Meaningful Community Service Look Like?", category:"Community", date:"July 2026", author:"CCI", imageClass:"second", excerpt:"Service should begin with listening. Communities should have a voice in shaping the solutions designed to support them.", content:"<p>Good intentions are not enough. Meaningful community service begins with listening to the people who understand a challenge firsthand.</p><p>CCI believes projects should be collaborative, respectful and responsive to the priorities of the communities involved.</p>" },
{ id:"youth-voices", title:"Young People Are Not Just the Future", category:"Youth Voices", date:"June 2026", author:"CCI", imageClass:"third", excerpt:"Young people already have the ideas, experiences and perspectives needed to contribute to change today.", content:"<p>Young people are often described as leaders of tomorrow. But young people are already researchers, organizers, volunteers, artists and advocates today.</p><p>Creating space for youth voices means giving young people real opportunities to contribute, lead and be heard.</p>" }
];

function articleCard(a){ return `<article class="article-card"><div class="article-image ${a.imageClass}"><span>${a.category.toUpperCase()}</span></div><div class="article-content"><small>${a.date} • ${a.author}</small><h3>${a.title}</h3><p>${a.excerpt}</p><a href="article.html?id=${a.id}">Read article →</a></div></article>`; }

function renderArticles(list, target){ const el=document.getElementById(target); if(el) el.innerHTML=list.map(articleCard).join("") || "<p>No articles found.</p>"; }

document.addEventListener("DOMContentLoaded",()=>{
 const grid=document.getElementById("articleGrid");
 const latest=document.getElementById("latestArticles");
 if(grid){
   const search=document.getElementById("searchInput"), filter=document.getElementById("categoryFilter");
   const update=()=>{const q=search.value.toLowerCase(), c=filter.value; renderArticles(articles.filter(a=>(c==="All"||a.category===c)&&(a.title.toLowerCase().includes(q)||a.excerpt.toLowerCase().includes(q))),"articleGrid");};
   search.addEventListener("input",update); filter.addEventListener("change",update); update();
 }
 if(latest) renderArticles(articles.slice(0,3),"latestArticles");
 const page=document.getElementById("articlePage");
 if(page){
   const id=new URLSearchParams(location.search).get("id"), a=articles.find(x=>x.id===id)||articles[0];
   document.title=a.title+" | CCI";
   page.innerHTML=`<div class="article-header"><span class="section-label">${a.category.toUpperCase()}</span><h1>${a.title}</h1><p>${a.date} • ${a.author}</p></div><div class="article-body">${a.content}</div><a class="text-link" href="articles.html">← Back to articles</a>`;
 }
});